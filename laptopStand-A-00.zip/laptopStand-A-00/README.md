# Laptop Stand – Release A-00

STEP files for two versions of the laptop stand: **Single** and **Double**.

## Folder structure

```
laptopStand-A-00/
├── _assembly_laptopStandSingle-A-00/
│   ├── _assembly_laptopStandSingle-A-00.step   full assembly
│   ├── P1-A-00_ALU5052-3_18MM-MAKE1.step
│   ├── P2-A-00_ALU5052-3_18MM-MAKE1.step
│   └── P4-A-00_UHMW-12_7MM-MAKE2.step
└── _assembly_laptopStandDouble-A-00/
    ├── _assembly_laptopStandDouble-A-00.step   full assembly
    ├── P1-A-00_ALU5052-3_18MM-MAKE1.step
    ├── P2-A-00_ALU5052-3_18MM-MAKE1.step
    └── P3-A-00_UHMW-12_7MM-MAKE2.step
```

Each folder is one complete, self-contained build: the `_assembly_*.step` file shows how that version goes together, and every other file in the folder is a part to fabricate. P1 and P2 are the same in both versions.

## Part file names

Part names tell you what to make:

```
P1-A-00_ALU5052-3_18MM-MAKE1.step
│  │  │  │         │     └─ quantity to make (MAKE1 = 1, MAKE2 = 2)
│  │  │  │         └─────── thickness (3_18MM = 3.18 mm)
│  │  │  └───────────────── material (ALU5052 = 5052 aluminum, UHMW = UHMW polyethylene)
│  │  └──────────────────── revision (00)
│  └─────────────────────── release letter (A)
└────────────────────────── part number
```

| Part | Material | Thickness | Qty |
|------|----------|-----------|-----|
| P1 (Single, Double) | 5052 aluminum | 3.18 mm | 1 |
| P2 (Single, Double) | 5052 aluminum | 3.18 mm | 1 |
| P4 (Single only) | UHMW | 12.7 mm | 2 |
| P3 (Double only) | UHMW | 12.7 mm | 2 |

## Hardware

Hardware is **M5** and depends on the thickness of your laptop (closed). Choose bolt length accordingly:

- **Single**: sized for laptops up to **75 mm** thick
- **Double**: sized for laptops up to **45 mm** thick

## Recommended: PEM inserts

Use PEM self-clinching nuts on one of the mating parts so the M5 bolts thread into the plate instead of needing a loose nut.

**Flush Nut, M5 x 0.8, 2**  (~$1.53 ea)

| Spec | Value |
|------|-------|
| Thread size | M5 x 0.8 |
| Fastener material | 300 series stainless steel |
| Finish | Passivated |
| Thickness (A) | 0.090" |
| Base width (H) | 0.343" |
| Shank | 2 |
| Min centerline to edge distance | 0.315" |
| Tooling diameter | 0.51" |
